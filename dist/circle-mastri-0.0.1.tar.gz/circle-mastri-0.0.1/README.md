# Circle Package

This is a small package calculating the area and circumference of a circle.

By using the function calculate_circumference which takes the radius as an input, you get the circumference of a circle with the given radius.
The function calculate_area also takes the radius as an input and returns the area of the circle with given radius.

Enjoy using my first package!