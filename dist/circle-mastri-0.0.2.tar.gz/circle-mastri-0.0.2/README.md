# Circle Package

This is a small package calculating the area and circumference of a circle.

By using the function calculate_circumference which takes the radius as an input, you get the circumference of a circle with the given radius.
The function calculate_area also takes the radius as an input and returns the area of the circle with given radius.

The new version also sports a graphic user interface option, opened with the function circle_data_gui.

Enjoy using my first package!